##### AllergyIntolerance
TBD

##### CarePlan
TBD

##### CareTeam
TBD

##### Condition
TBD

##### Device
TBD

##### DiagnosticReport
TBD

##### DocumentReference
TBD

##### Encounter
TBD

##### Goal
TBD

##### Immunization
TBD

##### Location
TBD

##### MedicationRequest
TBD

##### Observation
TBD

##### Organization
TBD

##### Patient
TBD

##### Practitioner
TBD

##### PractitionerRole
TBD

##### Procedure
TBD

##### QuestionnaireResponse
TBD

##### RelatedPerson
TBD

##### ServiceRequest
TBD
